#include "interface.h"

void Eingabe (void)
{
    int j;
    for (j=0; j<DIM; j++) Ar[j] = j+1;
}