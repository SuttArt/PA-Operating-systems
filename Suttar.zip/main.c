#include "interface.h"

int main(void)
{
    printf("It works!");
    Eingabe();
    Ausgabe();
    printf("\nThat is all, Leute...\n");

    return 0;
}