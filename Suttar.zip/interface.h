#include <stdio.h>

// constants

#define DIM 5

// Globales Array
int Ar[DIM];

// Interface
void Eingabe (void);
void Ausgabe (void);